#ifndef CLI_H
#define CLI_H

#include "common.h"
#include "data.h"
#include "queue.h"

void cli_loop(void);

#endif